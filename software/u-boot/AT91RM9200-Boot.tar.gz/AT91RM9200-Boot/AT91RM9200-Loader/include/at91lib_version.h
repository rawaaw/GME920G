//*----------------------------------------------------------------------------
//*         ATMEL Microcontroller Software Support  -  ROUSSET  -
//*----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*----------------------------------------------------------------------------
//* File Name           : at91lib_version_h
//* Object              :
//*
//* 1.0 Oct 11th  HI ODi : Creation
//*----------------------------------------------------------------------------
#ifndef at91lib_version_h
#define at91lib_version_h

#define AT91C_LIB_VERSION (0x00000009)

#endif // at91lib_version_h